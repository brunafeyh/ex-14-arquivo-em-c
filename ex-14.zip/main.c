#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int dia, mes, ano;
} Data;

typedef struct {
    char *nome;
    Data nascimento;
    int idade;
} Pessoa;

void lerData(FILE *arquivo, Pessoa *pessoa) {
    fscanf(arquivo, "%d", &pessoa->nascimento.dia);
    fscanf(arquivo, "%d", &pessoa->nascimento.mes);
    fscanf(arquivo, "%d", &pessoa->nascimento.ano);
    fscanf(arquivo, "%*c");
}

int carregarArquivo(char *nomeArquivo, Pessoa *pessoas[], int *quantidadePessoas) {
    FILE *arquivo;
    int i;
    char buffer[1000] = "";

    arquivo = fopen(nomeArquivo, "r");

    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    for (i = 0; fscanf(arquivo, "%[^\n]%*c", buffer) != EOF; i++) {
        pessoas[i] = (Pessoa *)malloc(sizeof(Pessoa));
        pessoas[i]->nome = (char *)malloc(strlen(buffer) + 1);
        strcpy(pessoas[i]->nome, buffer);
        lerData(arquivo, pessoas[i]);
    }

    *quantidadePessoas = i;
    fclose(arquivo);
    return 0;
}

int criarRelatorio(char *nomeArquivo, Pessoa *pessoas[], int quantidade) {
    FILE *arquivo;
    int i;
    arquivo = fopen(nomeArquivo, "w");

    if (!arquivo) {
        perror("Erro ao abrir o arquivo de relatório");
        return 1;
    }

    fprintf(arquivo, "NOME                     NASCIMENTO    IDADE\n");
    for (i = 0; i < quantidade; i++) {
        fprintf(arquivo, "%-25s%02d/%02d/%d%8d\n", pessoas[i]->nome, pessoas[i]->nascimento.dia,
                pessoas[i]->nascimento.mes, pessoas[i]->nascimento.ano, pessoas[i]->idade);
    }

    fclose(arquivo);
    return 0;
}

void calcularIdade(Pessoa *pessoas[], int quantidade, int dia, int mes, int ano) {
    int i;

    for (i = 0; i < quantidade; i++) {
        if ((pessoas[i]->nascimento.mes < mes) ||
            (pessoas[i]->nascimento.mes == mes && pessoas[i]->nascimento.dia <= dia)) {
            pessoas[i]->idade = ano - pessoas[i]->nascimento.ano;
        } else {
            pessoas[i]->idade = ano - pessoas[i]->nascimento.ano - 1;
        }
    }
}

void liberarMemoria(Pessoa *pessoas[], int quantidade) {
    int i;

    for (i = 0; i < quantidade; i++) {
        free(pessoas[i]->nome);
        free(pessoas[i]);
    }
}

int main() {
    Pessoa *pessoasArray[100];
    int quantidadeDePessoas, dia, mes, ano;
    char nomeArquivo[40];

    printf("Digite o nome do arquivo: ");
    scanf("%[^\n]%*c", nomeArquivo);

    if (carregarArquivo(nomeArquivo, pessoasArray, &quantidadeDePessoas) != 0) {
        return 1;
    }

    printf("Digite a data atual no formato dd mm aaaa: ");
    scanf("%d %d %d", &dia, &mes, &ano);

    calcularIdade(pessoasArray, quantidadeDePessoas, dia, mes, ano);
    criarRelatorio("relatorio.txt", pessoasArray, quantidadeDePessoas);
    liberarMemoria(pessoasArray, quantidadeDePessoas);

    return 0;
}
